// GET /api/facility?id=<uuid> -> one facility with all services and indicative prices.
const { facilityById, shapeFacility, priceByFacility, freshness } = require('./lib/store');
const { json } = require('./lib/http');

exports.handler = async (event) => {
  const id = (event.queryStringParameters || {}).id;
  const f = facilityById.get(id);
  if (!f) return json(404, { error: 'Facility not found' });
  const now = new Date();
  const prices = (priceByFacility.get(id) || []).map((p) => ({
    item: p.item,
    category: p.category,
    min: p.price_min,
    max: p.price_max,
    source: p.source,
    freshness: freshness(p.updated_at, now),
  }));
  return json(200, { ...shapeFacility(f, now), prices });
};
