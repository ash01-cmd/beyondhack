// GET /api/services -> service list with counts, for the "Common searches" row.
const { parseJson, services, facilityById, svcByFacility } = require('./lib/store');
const { json } = require('./lib/http');

exports.handler = async () => {
  const counts = new Map();
  for (const [fid, list] of svcByFacility) {
    if (!facilityById.has(fid)) continue;
    for (const fs of list) {
      if (fs.status === 'unavailable') continue;
      counts.set(fs.service_id, (counts.get(fs.service_id) || 0) + 1);
    }
  }
  const out = services
    .map((s) => ({ id: s.id, name: s.name, category: s.category, description: s.plain_description, aliases: parseJson(s.aliases, []), facilityCount: counts.get(s.id) || 0 }))
    .sort((a, b) => b.facilityCount - a.facilityCount);
  return json(200, { services: out });
};
