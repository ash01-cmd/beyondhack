// GET /api/search?service=Dialysis&district=Chengalpattu&language=Tamil&open24x7=1&limit=20
//   service   service name, alias ("kidney wash", "xray") or service id
//   q         free text over facility name, district, address and service names
//   district  exact district name
//   language  e.g. Tamil, English
//   open24x7  1 to require 24x7 facilities
//   hideUnavailable  1 to drop services marked unavailable
// No coordinates are sent: the browser sorts by distance itself, so location never leaves the device.
const { facilities, shapeFacility, termMatches } = require('./lib/store');
const { json } = require('./lib/http');

const norm = (s) => String(s || '').toLowerCase().trim();
const STATUS_RANK = { available: 0, limited: 1, unavailable: 2 };

exports.handler = async (event) => {
  const p = event.queryStringParameters || {};
  const now = new Date();
  const service = norm(p.service);
  const q = norm(p.q);
  const limit = Math.min(Number(p.limit) || 30, 100);

  let results = [];
  for (const f of facilities) {
    if (p.district && norm(f.district) !== norm(p.district)) continue;
    if (p.open24x7 === '1' && !f.open_24x7) continue;
    const shaped = shapeFacility(f, now);
    if (p.language && !shaped.languages.map(norm).includes(norm(p.language))) continue;

    let matched = shaped.services;
    if (service) {
      matched = matched.filter((s) => s.id === p.service || s.terms.some((t) => termMatches(t, service)));
      if (!matched.length) continue;
    }
    if (p.hideUnavailable === '1') matched = matched.filter((s) => s.status !== 'unavailable');
    if (service && !matched.length) continue;
    if (q) {
      const hay = norm([shaped.name, shaped.district, shaped.address, ...shaped.services.flatMap((s) => s.terms)].join(' '));
      if (!hay.includes(q)) continue;
    }
    results.push({ ...shaped, matchedServices: service ? matched : [] });
  }

  // Server-side default order: best service status, then freshest verification, then listing trust.
  const best = (r) => (r.matchedServices.length ? Math.min(...r.matchedServices.map((s) => STATUS_RANK[s.status] ?? 3)) : 0);
  const fresh = (r) => (r.matchedServices.length ? Math.min(...r.matchedServices.map((s) => s.freshness.days ?? 9999)) : 0);
  results.sort((a, b) => best(a) - best(b) || fresh(a) - fresh(b) || b.listingTrust.score - a.listingTrust.score);

  return json(200, { count: results.length, results: results.slice(0, limit) });
};
